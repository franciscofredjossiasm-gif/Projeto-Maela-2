(function () {
  "use strict";

  var pageLoadedAt = Date.now();

  document.addEventListener("DOMContentLoaded", function () {
    var anoAtual = document.getElementById("anoAtual");
    if (anoAtual) { anoAtual.textContent = new Date().getFullYear(); }

    /* Menu móvel */
    var toggle = document.getElementById("navToggle");
    var nav = document.getElementById("mainNav");

    function closeNav() {
      if (!nav) return;
      nav.classList.remove("open");
      if (toggle) toggle.setAttribute("aria-expanded", "false");
    }

    if (toggle && nav) {
      toggle.addEventListener("click", function () {
        var isOpen = nav.classList.toggle("open");
        toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      });
      nav.querySelectorAll(".nav-link").forEach(function (link) {
        link.addEventListener("click", closeNav);
      });
      document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") closeNav();
      });
    }

    /* Botão voltar ao topo */
    var backToTop = document.getElementById("backToTop");
    if (backToTop) {
      window.addEventListener("scroll", function () {
        backToTop.classList.toggle("show", window.scrollY > 500);
      });
      backToTop.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }

    /* Diaporama de fotografias no hero da Home */
    var slides = document.querySelectorAll("#heroSlides .hero-slide");
    if (slides.length > 1) {
      var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!reduceMotion) {
        var currentSlide = 0;
        setInterval(function () {
          slides[currentSlide].classList.remove("is-active");
          currentSlide = (currentSlide + 1) % slides.length;
          slides[currentSlide].classList.add("is-active");
        }, 5000);
      }
    }

    /* Formulário de contacto */
    var form = document.getElementById("contactForm");
    var status = document.getElementById("formStatus");

    if (form && status) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        status.className = "form-status";
        status.textContent = "";

        /* Anti-spam 1: campo honeypot deve permanecer vazio */
        var honeypot = form.querySelector("#website");
        if (honeypot && honeypot.value) {
          status.classList.add("error");
          status.textContent = "Não foi possível validar o pedido.";
          return;
        }

        /* Anti-spam 2: rejeita envios instantâneos típicos de robôs */
        var elapsedSeconds = (Date.now() - pageLoadedAt) / 1000;
        if (elapsedSeconds < 3) {
          status.classList.add("error");
          status.textContent = "Por favor, reveja o formulário antes de enviar.";
          return;
        }

        var nome = form.nome.value.trim();
        var telefone = form.telefone.value.trim();
        var email = form.email.value.trim();
        var mensagem = form.mensagem.value.trim();
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!nome || !telefone || !email || !mensagem) {
          status.classList.add("error");
          status.textContent = "Por favor, preencha todos os campos antes de enviar.";
          return;
        }

        if (!emailPattern.test(email)) {
          status.classList.add("error");
          status.textContent = "Introduza um endereço de e-mail válido.";
          return;
        }

        /* Este site é estático (sem servidor próprio), por isso o pedido é
           preparado como e-mail pronto a enviar para o escritório. Quando o
           cliente contratar alojamento com processamento de formulários
           (ex.: Resend, Formspree), este bloco pode ser substituído por um
           envio directo em segundo plano. */
        var destinatario = "juniordossantospaulomante@gmail.com";
        var assunto = "Pedido de informacao/reserva - site institucional";
        var corpo =
          "Nome: " + nome + "\n" +
          "Telefone: " + telefone + "\n" +
          "E-mail: " + email + "\n\n" +
          "Mensagem:\n" + mensagem;

        var mailtoLink =
          "mailto:" + encodeURIComponent(destinatario) +
          "?subject=" + encodeURIComponent(assunto) +
          "&body=" + encodeURIComponent(corpo);

        window.location.href = mailtoLink;

        status.classList.add("success");
        status.textContent =
          "A abrir a sua aplicação de e-mail com o pedido já preenchido. " +
          "Se não abrir automaticamente, contacte-nos directamente para " +
          destinatario + ".";
        form.reset();
      });
    }
  });
})();
